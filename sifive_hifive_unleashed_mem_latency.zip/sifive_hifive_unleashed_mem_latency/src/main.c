/* Copyright 2019 SiFive, Inc */
/* SPDX-License-Identifier: Apache-2.0 */
#include <metal/cache.h>
#include <metal/cpu.h>
#include <metal/timer.h>
#include <stdio.h>
#include <stdlib.h>

#include "latency_test.h"

void _dma(int* addr, int size);
void display_banner();

#define K 1023

extern char metal_segment_heap_target_start;
extern char metal_segment_heap_target_end;

char *heap_start_location = &metal_segment_heap_target_start;
char *heap_end_location = &metal_segment_heap_target_end;

#define K_TO_BYTE(x) (x * 1024)

/* Defines to access CSR registers within C code */
#define read_csr(reg) ({ unsigned long __tmp; \
  asm volatile ("csrr %0, " #reg : "=r"(__tmp)); \
  __tmp; })

#define write_csr(reg, val) ({ \
  asm volatile ("csrw " #reg ", %0" :: "rK"(val)); })

int ddr_array_1k[K];

void benchmark_latency(int* ddr_addr,int size) {

    _dma(ddr_addr,size);
}

int main() {
    size_t heap_size = (size_t)(heap_end_location - heap_start_location);
    int start_cycle ;
    int end_cycle	;

    uint64_t cycle_count = 0;

    display_banner();

    printf("---test start---\n");

    printf("heap size: %u K\n", (unsigned int)heap_size / 1024);

    // benchmark
    start_cycle = read_csr(cycle);

    benchmark_latency(ddr_array_1k, K);

    end_cycle = read_csr(cycle);

    cycle_count = end_cycle - start_cycle;

    printf("1K transfer from DDR to DTIM %u  cycles\n", (unsigned int)(cycle_count));

    printf("---test end---\n");
    exit(0);
}

