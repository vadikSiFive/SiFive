/*
 * utils.c
 *
 *  Created on: Oct 1, 2020
 *      Author: vadim.malenboim
 */



void display_banner (void) {

    printf("\n");
    printf("\n");
    printf("                  SIFIVE, INC.\n");
    printf("\n");
    printf("           5555555555555555555555555\n");
    printf("          5555                   5555\n");
    printf("         5555                     5555\n");
    printf("        5555                       5555\n");
    printf("       5555       5555555555555555555555\n");
    printf("      5555       555555555555555555555555\n");
    printf("     5555                             5555\n");
    printf("    5555                               5555\n");
    printf("   5555                                 5555\n");
    printf("  5555555555555555555555555555          55555\n");
    printf("   55555           555555555           55555\n");
    printf("     55555           55555           55555\n");
    printf("       55555           5           55555\n");
    printf("         55555                   55555\n");
    printf("           55555               55555\n");
    printf("             55555           55555\n");
    printf("               55555       55555\n");
    printf("                 55555   55555\n");
    printf("                   555555555\n");
    printf("                     55555\n");
    printf("                       5\n");
    printf("\n");

    printf("\n");
    printf("               Welcome to SiFive!\n");

}


/********************************************************************************/

// optimization of memcpy?
// cache - flash/fence between the runs dma and memcpy.
// fetch data (from ddr), process data (in dtim), send it back(to ddr)
// check round trip latency ( cpu processing will be the same, difference will be in data movement).
// load process and store data from dtim ( to eliminate ddr from the equasion)

//bare-metal frequency ?
//set a higher frequency ? (Nate)
//memory/ddr clock

// pll - freedom

//__attribute((section(".data.ddr"))) int ddr_array[63];
/********************************************************************************/
