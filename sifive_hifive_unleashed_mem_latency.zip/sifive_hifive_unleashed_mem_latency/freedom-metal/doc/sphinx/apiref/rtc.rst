Real-Time Clock
===============

.. doxygenfile:: metal/rtc.h
   :project: metal

