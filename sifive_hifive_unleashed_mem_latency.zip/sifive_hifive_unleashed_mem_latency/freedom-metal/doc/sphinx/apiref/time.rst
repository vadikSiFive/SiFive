Time
====

.. doxygenfile:: metal/time.h
   :project: metal

