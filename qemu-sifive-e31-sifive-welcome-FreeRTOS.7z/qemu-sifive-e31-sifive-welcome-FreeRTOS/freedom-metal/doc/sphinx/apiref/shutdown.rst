Shutdown
========

.. doxygenfile:: metal/shutdown.h
   :project: metal

