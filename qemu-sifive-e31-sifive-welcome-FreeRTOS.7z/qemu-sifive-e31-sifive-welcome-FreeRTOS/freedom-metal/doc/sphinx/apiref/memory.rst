Memory Enumeration
==================

.. doxygenfile:: metal/memory.h
   :project: metal

