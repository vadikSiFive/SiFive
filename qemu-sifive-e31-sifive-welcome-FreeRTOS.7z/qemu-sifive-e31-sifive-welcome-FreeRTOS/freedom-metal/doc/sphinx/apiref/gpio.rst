GPIO
====

.. doxygenfile:: metal/gpio.h
   :project: metal
