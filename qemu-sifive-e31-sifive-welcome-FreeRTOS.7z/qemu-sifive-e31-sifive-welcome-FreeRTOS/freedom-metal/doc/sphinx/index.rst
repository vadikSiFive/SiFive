Freedom Metal
=============

This is the documentation for the SiFive Freedom Metal library |version|.

Freedom Metal is generally available from the `Freedom Metal GitHub Repository`_.

.. _Freedom Metal GitHub Repository:
   https://github.com/sifive/freedom-metal

Table of Contents
-----------------

.. toctree::
   :maxdepth: 2

   introduction
   devguide
   api

Indices and tables
------------------

* :ref:`genindex`
* :ref:`search`
