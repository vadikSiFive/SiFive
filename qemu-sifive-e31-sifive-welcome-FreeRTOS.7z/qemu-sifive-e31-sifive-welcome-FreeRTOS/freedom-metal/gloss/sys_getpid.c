#include <errno.h>

int
_getpid()
{
  return 1;
}
