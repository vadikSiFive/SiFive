# example-freertos-blinky
A simple blinky starter application create just two tasks, one queue
